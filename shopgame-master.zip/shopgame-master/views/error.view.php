<div class="error-page mt-5">
    <div class="container">
        <div class="col-md-12 col-sm-8 col-xs-8">
            <div class="error_pagenotfound"> <strong>4<span id="animate-arrow">0</span>4 </strong> <br />
                <b>Ohh... Không tìm thấy trang!</b> <em>Xin lỗi, trang không thể được tìm thấy ở đây.</em>
                <p>Hãy thử sử dụng nút bên dưới để đi đến trang chủ của trang web</p>
                <br />
                <a href="/" class="button-back"><i class="fa fa-arrow-circle-left fa-lg"></i>&nbsp; Trở
                    về</a>
            </div>
            <!-- end error page notfound -->

        </div>
    </div>
</div>