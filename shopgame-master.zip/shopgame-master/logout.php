<?php
require_once'controllers/Controller.php';

$data=new Controller;
return $data->Logout();
?>